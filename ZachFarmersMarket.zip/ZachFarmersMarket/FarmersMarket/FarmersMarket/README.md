# Farmer's Market
<br/>

## Functionality
- The user can:
    - Create new farmers and stands
    - View each stand's stock, name, location, and farmer name
    - Purchase produce from specific stands
    - Give stock to specific stands
<br/>

## Known Bugs
- SQL injection issues can occur with textboxes (Ex: Using apostrophes)
- Textboxes which take numeric input throw exceptions with non-validated Int32.Parse operations
- Stand statistics (upper right corner of UI) will iterate once occasionally when a purchase or creation of stock takes place
<br/>

## Additional Comments
- While somewhat redundant, the database implementation is to save the market through multiple application uses and demonstrate experience with such
- My reason for using a WPF was to broaden my project-type experience as I haven't worked on a WPF project before
- With more time (and now more experience) I could improve upon this project. That is, fix bugs, make the UI more usable/appealing, improve performance, add more validation for user input, modify the database constraints, organize the C# better, etc...