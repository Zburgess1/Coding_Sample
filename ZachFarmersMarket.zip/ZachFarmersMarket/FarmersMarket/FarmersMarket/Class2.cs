﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmersMarket
{

    /*
     * Each class inherits from its respective Abstract class
     * Constructors set names respectively and set prices arbitrarily
    */

    internal class Orange : Fruit
    {
        public Orange()
        {
            this._name = "Orange";
            this._price = 1;
        }
    }

    internal class Apple : Fruit
    {
        public Apple()
        {
            this._name = "Apple";
            this._price = 2;
        }
    }

    internal class Pear : Fruit
    {
        public Pear()
        {
            this._name = "Pear";
            this._price = 3;
        }
    }

    internal class Tomato : Fruit
    {
        public Tomato()
        {
            this._name = "Tomato";
            this._price = 1;
        }
    }

    internal class Potato : Vegetable
    {
        public Potato()
        {
            this._name = "Potato";
            this._price = 1;
        }
    }

    internal class BellPepper : Vegetable
    {
        public BellPepper()
        {
            this._name = "BellPepper";
            this._price = 3;
        }
    }
}
