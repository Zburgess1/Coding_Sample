﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmersMarket
{
    
    internal abstract class Produce
    {
        protected string _name;
        protected string _type;
        protected int _price;

        public string getName()
        {
            return this._name;
        }

        public string getType()
        {
            return this._type;
        }

        public int getPrice()
        {
            return this._price;
        }
    }
}
