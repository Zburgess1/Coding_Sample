﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmersMarket
{

    // Object composed of stands which makes up the market
    internal class FarmerMarket
    {
        private List<Stand> market;
        private DataTable dt = new DataTable();

        public FarmerMarket()
        {
            this.market = new List<Stand>();

            sqlHelper();

            for(int i = 0; i < dt.Rows.Count; i++)
            {
                this.market.Add(new Stand((string)dt.Rows[i][1], (string)dt.Rows[i][2], new Farmer((string)dt.Rows[i][5], (int)dt.Rows[i][6])));
                this.market[i].startStock();
            }
        }
        
        // Adds a new stand to the list
        public void addStand(string standName, string location, string farmerName, int farmerAge)
        {
            this.market.Add(new Stand(standName, location, new Farmer(farmerName, farmerAge)));
            newStand(standName, location, farmerName, farmerAge);
        }

        public int getSize()
        {
            return market.Count;
        }

        public List<Stand> getStands()
        {
            return this.market;
        }

        public Stand getStand(int index)
        {
            return this.market[index];
        }

        // Connects to, and queries the database. The returned data is stored in the global DataTable.
        private void sqlHelper()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["FarmersMarket"].ConnectionString;

                SqlDataAdapter sda = new SqlDataAdapter();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "SELECT * FROM Stand JOIN Farmer ON Farmer.Id = Stand.FarmerId;";

                sda.SelectCommand = cmd;

                conn.Open();
                SqlDataReader read = cmd.ExecuteReader();
                if (read.Read())
                {
                    read.Close();
                    sda.Fill(dt);
                }
                else
                {
                    Console.WriteLine("No entries");
                }

            }
        }

        // Inserts new entries in the database respectively
        private void newStand(string standName, string location, string farmerName, int farmerAge)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["FarmersMarket"].ConnectionString;

                SqlCommand cmd1 = new SqlCommand();
                SqlCommand cmd2 = new SqlCommand();
                SqlCommand cmd3 = new SqlCommand();
                cmd1.Connection = conn;
                cmd2.Connection = conn;
                cmd3.Connection = conn;
                cmd1.CommandText = "INSERT INTO Farmer (Name, Age) VALUES ('" + farmerName + "', '" + farmerAge + "');";
                cmd2.CommandText = "INSERT INTO Stand (Name, Location, FarmerId) VALUES ('" + standName + "', '" + location + "', (SELECT MAX(Id) FROM Farmer));";
                cmd3.CommandText = "INSERT INTO Stock (ProduceId, StandId, Amount) VALUES (1, (SELECT MAX(Id) FROM Stand), 0), (2, (SELECT MAX(Id) FROM Stand), 0), (3, (SELECT MAX(Id) FROM Stand), 0), (4, (SELECT MAX(Id) FROM Stand), 0), (5, (SELECT MAX(Id) FROM Stand), 0), (6, (SELECT MAX(Id) FROM Stand), 0);";

                conn.Open();
                cmd1.ExecuteNonQuery();
                cmd2.ExecuteNonQuery();
                cmd3.ExecuteNonQuery();
            }
        }
    }
}
