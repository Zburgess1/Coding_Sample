﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace FarmersMarket
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        // Globals
        private FarmerMarket mainMarket;
        private int iterator = 0;
        private int[] amounts = new int[6];

        public MainWindow()
        {
            InitializeComponent();
        }

        // Reads from the database to populate the market and enables specific controls
        private void btnCreateMarket_Click(object sender, RoutedEventArgs e)
        {
            mainMarket = new FarmerMarket();
            btnCreateMarket.IsEnabled = false;
            txtFarmerName.IsEnabled = true;
            btnIterator.IsEnabled = true;
            btnAddStock.IsEnabled = true;
            btnPurchase.IsEnabled = true;
            txtFarmerSpecify.IsEnabled = true;
            txtStandSpecify.IsEnabled = true;
            txtApple.IsEnabled = true;
            txtBellPepper.IsEnabled = true;
            txtOrange.IsEnabled = true;
            txtPear.IsEnabled = true;
            txtTomato.IsEnabled = true;
            txtPotato.IsEnabled = true;
        }

        private void txtStandName_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(btnCreateNewStand != null)
            {
                txtStandLocation.IsEnabled = true;
            }
            
        }

        // Populates the market list and database with a new stand and farmer
        private void btnCreateNewStand_Click(object sender, RoutedEventArgs e)
        {
            mainMarket.addStand(txtStandName.Text, txtStandLocation.Text, txtFarmerName.Text, Int32.Parse(txtFarmerAge.Text));
            txtStandName.Text = "Stand name here...";
            txtFarmerName.Text = "Farmer name here...";
            txtFarmerAge.Text = "Farmer age here...";
            txtStandLocation.Text = "Stand location here...";
            txtStandLocation.IsEnabled = false;
            txtFarmerAge.IsEnabled = false;
            txtStandName.IsEnabled = false;
            btnCreateNewStand.IsEnabled = false;
        }

        private void txtFarmerName_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(txtFarmerAge != null)
            {
                txtFarmerAge.IsEnabled = true;
            }
            
        }

        // Validates the input farmer age
        private void txtFarmerAge_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtFarmerAge != null && lblAgeValid != null && txtStandName != null)
            {
                if (!(Int32.TryParse(txtFarmerAge.Text, out int value)) || (Int32.Parse(txtFarmerAge.Text) < 18 || Int32.Parse(txtFarmerAge.Text) > 130))
                {
                    lblAgeValid.Visibility = Visibility.Visible;
                    txtStandName.IsEnabled = false;
                }
                else
                {
                    if(lblAgeValid != null)
                    {
                        lblAgeValid.Visibility = Visibility.Collapsed;
                        txtStandName.IsEnabled = true;
                    } 
                }
            }
        }

        private void txtStandLocation_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtStandName.IsEnabled == false)
            {
                btnCreateNewStand.IsEnabled = false;
            }
            else
            {
                btnCreateNewStand.IsEnabled = true;
            }
        }

        // Method for updating the stand statistics visible to the user
        private void statDisplay()
        {
            Stand temp = mainMarket.getStand(iterator);
            lblStandName.Content = temp.getName() + " " + "(" + temp.getLocation() + ")";
            lblFarmerName.Content = "Ran by: " + temp.getFarmer().getName();
            lblAppleCount.Content = "Apple Count = " + temp.checkStock(new Apple());
            lblOrangeCount.Content = "Orange Count = " + temp.checkStock(new Orange());
            lblPearCount.Content = "Pear Count = " + temp.checkStock(new Pear());
            lblTomatoCount.Content = "Tomato Count = " + temp.checkStock(new Tomato());
            lblPotatoCount.Content = "Potato Count = " + temp.checkStock(new Potato());
            lblBellPepperCount.Content = "Bell Pepper Count = " + temp.checkStock(new BellPepper());
        }

        // Iterates through the market list
        private void btnIterator_Click(object sender, RoutedEventArgs e)
        {
            if(iterator == mainMarket.getSize() - 1)
            {
                statDisplay();
                iterator = 0;
            }
            else
            {
                statDisplay();
                iterator++;
            }
        }

        // Resets specific controls
        private void btnPurchase_Click(object sender, RoutedEventArgs e)
        {
            if (verifyPurchase() && verifyAdd())
            {
                setAmounts();
                purchase();
                txtApple.Text = "0";
                txtOrange.Text = "0";
                txtPear.Text = "0";
                txtPotato.Text = "0";
                txtTomato.Text = "0";
                txtBellPepper.Text = "0";
                txtFarmerSpecify.Text = "Farmer name";
                txtStandSpecify.Text = "Stand name";
                statDisplay();
            }
        }

        // Verifies that the input strings exist and the input amounts don't exceed stock amounts
        private bool verifyPurchase()
        {
            foreach (Stand temp in mainMarket.getStands())
            {
                if (temp.getName().Equals(txtStandSpecify.Text) && temp.getFarmer().getName().Equals(txtFarmerSpecify.Text))
                {
                    lblNames.Visibility = Visibility.Collapsed;
                    if(temp.checkStock(new Apple()) >= Int32.Parse(txtApple.Text) && temp.checkStock(new Orange()) >= Int32.Parse(txtOrange.Text) && temp.checkStock(new Pear()) >= Int32.Parse(txtPear.Text) && temp.checkStock(new Tomato()) >= Int32.Parse(txtTomato.Text) && temp.checkStock(new Potato()) >= Int32.Parse(txtPotato.Text) && temp.checkStock(new BellPepper()) >= Int32.Parse(txtBellPepper.Text))
                    {
                        lblCheckStocks.Visibility = Visibility.Collapsed;
                        return true;
                    }
                    else
                    {
                        lblCheckStocks.Visibility = Visibility.Visible;
                        return false;
                    }
                }
            }

            lblNames.Visibility = Visibility.Visible;
            return false;
        }

        // Updates the database and market list after a purchase
        private void purchase()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["FarmersMarket"].ConnectionString;

                SqlCommand cmd1 = new SqlCommand();
                cmd1.Connection = conn;

                conn.Open();
                for (int i = 1; i < 7; i++)
                {
                    cmd1.CommandText = "UPDATE Stock SET Amount = (SELECT Amount FROM Stock WHERE ProduceId = '" + i + "' AND StandId = (SELECT Stand.Id FROM Stand JOIN Farmer ON Farmer.Id = Stand.FarmerId WHERE Farmer.Name = '" + txtFarmerSpecify.Text + "' AND Stand.Name = '" + txtStandSpecify.Text + "')) - '" + amounts[i - 1] + "' WHERE ProduceId = '" + i + "' AND StandId = (SELECT Stand.Id FROM Stand JOIN Farmer ON Farmer.Id = Stand.FarmerId WHERE Farmer.Name = '" + txtFarmerSpecify.Text + "' AND Stand.Name = '" + txtStandSpecify.Text + "');";
                    cmd1.ExecuteNonQuery();
                }
            }

            foreach (Stand temp in mainMarket.getStands())
            {
                if (temp.getName().Equals(txtStandSpecify.Text) && temp.getFarmer().getName().Equals(txtFarmerSpecify.Text))
                {
                    temp.reduceStock(new Apple(), Int32.Parse(txtApple.Text));
                    temp.reduceStock(new Orange(), Int32.Parse(txtOrange.Text));
                    temp.reduceStock(new Pear(), Int32.Parse(txtPear.Text));
                    temp.reduceStock(new Tomato(), Int32.Parse(txtTomato.Text));
                    temp.reduceStock(new Potato(), Int32.Parse(txtPotato.Text));
                    temp.reduceStock(new BellPepper(), Int32.Parse(txtBellPepper.Text));
                }
            }
        }

        // Resets specific controls
        private void btnAddStock_Click(object sender, RoutedEventArgs e)
        {
            if (verifyAdd())
            {
                setAmounts();
                createStock();
                txtApple.Text = "0";
                txtOrange.Text = "0";
                txtPear.Text = "0";
                txtPotato.Text = "0";
                txtTomato.Text = "0";
                txtBellPepper.Text = "0";
                txtFarmerSpecify.Text = "Farmer name";
                txtStandSpecify.Text = "Stand name";
                statDisplay();
            }
        }

        // Updates the database and market list after the user gives a stand stock
        private void createStock()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["FarmersMarket"].ConnectionString;

                SqlCommand cmd1 = new SqlCommand();
                cmd1.Connection = conn;

                conn.Open();
                for (int i = 1; i < 7; i++)
                {
                    cmd1.CommandText = "UPDATE Stock SET Amount = (SELECT Amount FROM Stock WHERE ProduceId = '" + i + "' AND StandId = (SELECT Stand.Id FROM Stand JOIN Farmer ON Farmer.Id = Stand.FarmerId WHERE Farmer.Name = '" + txtFarmerSpecify.Text + "' AND Stand.Name = '" + txtStandSpecify.Text + "')) + '" + amounts[i - 1] + "' WHERE ProduceId = '" + i + "' AND StandId = (SELECT Stand.Id FROM Stand JOIN Farmer ON Farmer.Id = Stand.FarmerId WHERE Farmer.Name = '" + txtFarmerSpecify.Text + "' AND Stand.Name = '" + txtStandSpecify.Text + "');";
                    cmd1.ExecuteNonQuery();
                }
            }

            foreach (Stand temp in mainMarket.getStands())
            {
                if (temp.getName().Equals(txtStandSpecify.Text) && temp.getFarmer().getName().Equals(txtFarmerSpecify.Text))
                {
                    temp.addStock(new Apple(), Int32.Parse(txtApple.Text));
                    temp.addStock(new Orange(), Int32.Parse(txtOrange.Text));
                    temp.addStock(new Pear(), Int32.Parse(txtPear.Text));
                    temp.addStock(new Tomato(), Int32.Parse(txtTomato.Text));
                    temp.addStock(new Potato(), Int32.Parse(txtPotato.Text));
                    temp.addStock(new BellPepper(), Int32.Parse(txtBellPepper.Text));
                }
            }
        }

        // Populates the global array with produce amounts
        private void setAmounts()
        {
            amounts[0] = Int32.Parse(txtOrange.Text);
            amounts[1] = Int32.Parse(txtApple.Text);
            amounts[2] = Int32.Parse(txtPear.Text);
            amounts[3] = Int32.Parse(txtTomato.Text);
            amounts[4] = Int32.Parse(txtPotato.Text);
            amounts[5] = Int32.Parse(txtBellPepper.Text);
        }

        // Verifies that the input strings exist and the input amounts are greater than 0
        private bool verifyAdd()
        {
            foreach (Stand temp in mainMarket.getStands())
            {
                if (temp.getName().Equals(txtStandSpecify.Text) && temp.getFarmer().getName().Equals(txtFarmerSpecify.Text))
                {
                    lblNames.Visibility = Visibility.Collapsed;
                    if (Int32.Parse(txtApple.Text) < 0 || Int32.Parse(txtOrange.Text) < 0 || Int32.Parse(txtPear.Text) < 0 || Int32.Parse(txtTomato.Text) < 0 || Int32.Parse(txtPotato.Text) < 0 || Int32.Parse(txtBellPepper.Text) < 0)
                    {
                        lblCheckValues.Visibility = Visibility.Visible;
                        return false;
                    }
                    else
                    {
                        lblCheckValues.Visibility= Visibility.Collapsed;
                        return true;
                    }
                }
            }

            lblNames.Visibility = Visibility.Visible;
            return false;
        }
    }
}
