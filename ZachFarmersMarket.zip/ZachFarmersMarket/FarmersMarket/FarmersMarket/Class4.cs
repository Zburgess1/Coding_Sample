﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmersMarket
{

    // Class to create market stands
    internal class Stand
    {
        private string _name;
        private string _location;
        private Farmer _farmer;
        private Dictionary<Produce, int> _stock;
        private DataTable dt = new DataTable();

        public Stand(string name, string location, Farmer farmer)
        {
            this._name = name;
            this._location = location;
            this._farmer = farmer;
            this._stock = new Dictionary<Produce, int>() { { new Apple(), 0}, { new Orange(), 0}, { new Pear(), 0 }, { new Tomato(), 0 }, { new Potato(), 0 }, { new BellPepper(), 0 } };
        }

        public string getName()
        {
            return this._name;
        }

        public Farmer getFarmer()
        {
            return this._farmer;
        }

        public string getLocation()
        {
            return this._location;
        }

        public Dictionary<Produce, int> getAllStock()
        {
            Dictionary<Produce, int> temp = new Dictionary<Produce, int>();
            foreach(KeyValuePair<Produce, int> kvp in this._stock)
            {
                temp.Add(kvp.Key, kvp.Value);
            }

            return temp;
        }

        // Method for adding produce stock to a stand
        public void addStock(Produce item, int amountAdded)
        {
            foreach (KeyValuePair<Produce, int> kvp in this._stock)
            {
                if (kvp.Key.getName().Equals(item.getName()))
                {
                    this._stock[kvp.Key] = this._stock[kvp.Key] + amountAdded;
                }
            }
        }

        // Method for reducing produce stock from a stand
        public void reduceStock(Produce item, int amountSubracted)
        {
            foreach (KeyValuePair<Produce, int> kvp in this._stock)
            {
                if (kvp.Key.getName().Equals(item.getName()))
                {
                    this._stock[kvp.Key] = this._stock[kvp.Key] - amountSubracted;
                }
            }
        }

        // Called when creating the market to populate the dictionary with the correct values from the database
        public void startStock()
        {
            sqlHelper();

            foreach(KeyValuePair<Produce, int> kvp in this._stock)
            {
                for(int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i][4].ToString().Equals(kvp.Key.getName()))
                    {
                        this._stock[kvp.Key] = (int)dt.Rows[i]["Amount"];
                    }
                }
            }
        }

        // Connects to, and queries the database. The returned data is stored in the global DataTable.
        private void sqlHelper()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["FarmersMarket"].ConnectionString;

                SqlDataAdapter sda = new SqlDataAdapter();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "SELECT * FROM Stock JOIN Produce ON Produce.Id = Stock.ProduceId JOIN Stand ON Stand.Id = Stock.StandId WHERE Stand.Name = '" + this.getName() + "';";

                sda.SelectCommand = cmd;

                conn.Open();
                SqlDataReader read = cmd.ExecuteReader();
                if (read.Read())
                {
                    read.Close();
                    sda.Fill(dt);
                }
                else
                {
                    Console.WriteLine("No entries");
                }

            }
        }

        // Method for checking the stock of a particular produce item
        public int checkStock(Produce item)
        {
            foreach(KeyValuePair<Produce, int> kvp in this._stock)
            {
                if (kvp.Key.getName().Equals(item.getName()))
                {
                    return kvp.Value;
                }
            }

            return 0;
        }
    }
}
