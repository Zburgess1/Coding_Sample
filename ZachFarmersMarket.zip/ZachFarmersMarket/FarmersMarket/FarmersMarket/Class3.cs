﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmersMarket
{

    // Class to create farmers
    internal class Farmer
    {
        private string _name;
        private int _age;

        public Farmer(string name, int age)
        {
            this._name = name;
            this._age = age;
        }

        public string getName()
        {
            return this._name;
        }

        public int getAge()
        {
            return this._age;
        }
    }
}
