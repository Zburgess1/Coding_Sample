﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmersMarket
{
    // Abstract class inherits Produce
    internal abstract class Fruit : Produce
    {

        // Sets type
        public Fruit()
        {
            this._type = "Fruit";
        }
    }

    // Abstract class inherits Produce
    internal abstract class Vegetable : Produce
    {

        // Sets type
        public Vegetable()
        {
            this._type = "Vegetable";
        }
    }
}
